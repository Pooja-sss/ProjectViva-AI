@echo off
setlocal
cd /d "%~dp0"
title ProjectViva AI - Setup and Launch

echo ======================================================
echo   ProjectViva AI - Local Project Interviewer
echo ======================================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js was not found.
  echo Install Node.js 20 LTS or newer from https://nodejs.org/ then reopen this file.
  pause
  exit /b 1
)
node -v
echo.
if not exist node_modules\react (
  echo Installing project dependencies. This requires internet on first run...
  call npm.cmd install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo Dependency installation failed. Check internet access, then run this file again.
    pause
    exit /b 1
  )
) else (
  echo Dependencies already installed; skipping install.
)
echo.
echo Starting ProjectViva AI on http://localhost:5173
echo You can close the server window to stop the app.
start "ProjectViva AI Server" /D "%~dp0" cmd /k "npm.cmd run dev -- --host 127.0.0.1"
timeout /t 4 /nobreak >nul
start "" "http://localhost:5173"
echo.
echo DEMO TIP: You can demo the interview and report without loading the optional WebGPU LLM.
echo For best stability, leave 'Use local language model when loaded' unchecked and type answers.
echo Speech and OCR models may need internet to download on their first use.
echo.
exit /b 0
