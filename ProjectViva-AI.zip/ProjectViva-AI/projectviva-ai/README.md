# ProjectViva AI — Local Project Interviewer

A browser-based hackathon MVP for interviewing students about their project presentations. The app has no application backend and requires no API keys.

## Important truth about the MVP

- Screen sharing: browser-native and local.
- OCR: Tesseract.js in browser. Its default setup downloads worker/WASM/language assets on first use.
- Speech-to-text: Transformers.js + Whisper Tiny in browser. First use downloads model assets.
- Interviewer: WebLLM + Qwen 2.5 0.5B quantized model via WebGPU. First use downloads model assets and needs compatible WebGPU.
- Fallback interviewer: deterministic local question rules, works without the LLM.
- Report: generated locally; downloadable JSON.
- Evaluation: intentionally heuristic/provisional, not a validated assessment instrument.

**This project is not fully offline on its first run.** First, dependencies and model/runtime assets must be downloaded. For a defensible offline demo, pre-download and self-host every model, tokenizer, worker, WASM and language asset, configure each library to use local paths, then test with internet disconnected. The browser app should be served locally over `localhost`; there is no application backend.

## Requirements

- Windows 11
- Node.js 20 LTS or newer
- Latest Microsoft Edge or Google Chrome
- 16 GB RAM recommended; WebGPU-capable graphics helps significantly
- Internet for initial npm/model downloads

## 1. Run the app (Windows)

For the easiest launch, double-click `RUN_PROJECTVIVA.bat`. It installs dependencies if needed, starts Vite, and opens the app. First-time dependency installation requires internet.

Manual PowerShell alternative:

```powershell
npm.cmd install
npm.cmd run dev
```

Open the localhost URL Vite prints (usually `http://localhost:5173`). See `SHOWCASE_GUIDE.md` for the reliable demo flow.

Build check:

```powershell
npm run build
```

## 2. Demo workflow

1. Enter a project name.
2. Click **Share screen** and choose a tab/window/screen.
3. Click **Scan with OCR**.
4. Paste or explain the project in the transcript/answer area if OCR misses content.
5. Click **Load AI** to load the local WebLLM model. This can take time and require several GB of download/cache.
6. Answer the interviewer question. For speech, click **Record answer**, speak briefly, then click **Stop & transcribe**.
7. Click **Submit & follow up** for the next question.
8. Click **Generate feedback report** and download JSON.

For a time-critical showcase, keep the optional WebGPU LLM unloaded and demonstrate the deterministic local interviewer; this avoids GPU/model initialization failures. Do not describe the fallback as LLM-powered. Load the LLM only after testing it on the same machine.

## 3. Check GPU/WebGPU on Windows

- Use current Chrome/Edge.
- Open `edge://gpu` or `chrome://gpu` and look for WebGPU/graphics support.
- In PowerShell, run `dxdiag` and inspect the Display tab for the GPU name.
- Update graphics drivers from the PC manufacturer or GPU vendor if WebGPU is unavailable.

## 4. Offline requirement checklist

Before claiming the challenge works fully offline:

- [ ] Install npm packages in advance.
- [ ] Cache/host the exact WebLLM model and its model config/tokenizer assets locally.
- [ ] Configure Transformers.js with a local model directory and `env.allowRemoteModels = false`.
- [ ] Host the Tesseract worker, all core WASM files, and `eng.traineddata.gz` locally.
- [ ] Self-host all other static assets; remove remote font imports if strict zero-network is required.
- [ ] Build (`npm run build`) and serve the static `dist` folder from localhost.
- [ ] Disconnect internet and reload from a fresh browser session.
- [ ] Use DevTools Network tab to verify no requests leave localhost.
- [ ] Test microphone, screen share, OCR, LLM, report download.
- [ ] Keep a fallback demo plan if hardware cannot run WebGPU.

## 5. Privacy

No app backend is included. Audio and screenshots are processed in the browser. Model/library assets may download from public hosting on first run unless configured for local assets. Never claim strict offline mode until the offline checklist passes.

## Troubleshooting

- `npm is not recognized`: install Node.js LTS, reopen PowerShell, run `node -v` and `npm -v`.
- WebGPU unavailable: use current Edge/Chrome and check graphics acceleration/driver. Use the deterministic fallback for the demo.
- Whisper `Unexpected token '<'` / `not valid JSON`: a model-file request returned HTML instead of JSON. The app uses `Xenova/whisper-tiny.en` and allows a retry after a failed load. Check the failed request in DevTools > Network; sign-in pages, proxies, VPN filters, or temporary Hugging Face errors can return HTML. Try again on a normal internet connection.
- WebLLM `DXGI_ERROR_DEVICE_HUNG`, `Device was lost`, or `Object has already been disposed`: the app now uses the smaller Qwen 0.5B model. If the GPU still crashes, the app disables further inference attempts for that page session and continues with its local deterministic fallback; reload the page to retry.
- Slow initial load: model downloads can be large. Download models before the presentation and allow caching to finish.
- OCR text is poor: zoom in on the slide/code, scan again, and manually correct the OCR text.


### Stability note (Windows integrated GPUs)

WebLLM is pinned to `0.2.82` because a reported regression in `0.2.83` and `0.2.84` can dispose cached shapes and cause `Object has already been disposed` / `DXGI_ERROR_DEVICE_HUNG` during longer prompts on some integrated GPUs. Whisper transcription is configured to use WASM/CPU so it does not compete with WebLLM for WebGPU resources. First-time model downloads require internet access.
