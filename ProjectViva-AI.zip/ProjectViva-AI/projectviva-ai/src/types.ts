export type Dimension = "Technical depth" | "Clarity" | "Originality" | "Implementation understanding";
export type Turn = {
  question: string;
  answer: string;
  dimension: Dimension;
  evidence: string;
  score?: number;
};
export type Scores = Record<Dimension, number>;
export type Report = {
  projectName: string;
  createdAt: string;
  overall: number;
  scores: Scores;
  strengths: string[];
  improvements: string[];
  turns: Turn[];
  screenText: string;
  transcript: string;
};