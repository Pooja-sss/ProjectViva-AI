import { useEffect, useRef, useState } from "react";
import {
  Activity, BrainCircuit, CheckCircle2, CircleHelp, Download, FileText, Mic, Monitor,
  Play, ScanText, ShieldCheck, Square, Volume2, WifiOff, LoaderCircle, Trash2
} from "lucide-react";
import { startScreenCapture, captureFrame } from "./services/screenCapture";
import { extractScreenText, terminateOcr } from "./services/ocrService";
import { transcribeBlob } from "./services/speechService";
import { generateQuestion, loadLocalLlm, speak, MODEL_ID } from "./services/interviewEngine";
import { buildReport, downloadReport } from "./services/evaluation";
import type { Report, Turn, Dimension } from "./types";

const dims: Dimension[] = ["Technical depth", "Clarity", "Originality", "Implementation understanding"];

export default function App() {
  const [projectName, setProjectName] = useState("My Project");
  const [screenText, setScreenText] = useState("");
  const [transcript, setTranscript] = useState("");
  const [question, setQuestion] = useState("Introduce your project: what problem does it solve, and who is it for?");
  const [answer, setAnswer] = useState("");
  const [turns, setTurns] = useState<Turn[]>([]);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [modelEnabled, setModelEnabled] = useState(true);
  const [llmReady, setLlmReady] = useState(false);
  const [llmProgress, setLlmProgress] = useState(0);
  const [report, setReport] = useState<Report | null>(null);
  const [micRecording, setMicRecording] = useState(false);
  const [ocrStatus, setOcrStatus] = useState("Waiting for screen");
  const [speechStatus, setSpeechStatus] = useState("Not loaded");
  const videoRef = useRef<HTMLVideoElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const micStreamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      void videoRef.current.play().catch(() => undefined);
    }
  }, [stream]);

  useEffect(() => () => {
    stream?.getTracks().forEach((track) => track.stop());
    micStreamRef.current?.getTracks().forEach((track) => track.stop());
    window.speechSynthesis?.cancel();
    void terminateOcr();
  }, [stream]);

  const shareScreen = async () => {
    setError("");
    try {
      await startScreenCapture(setStream);
      setOcrStatus("Screen shared — ready to scan");
    } catch (e) { setError((e as Error).message); }
  };

  const stopScreen = () => {
    stream?.getTracks().forEach((track) => track.stop());
    setStream(null);
    setOcrStatus("Screen sharing stopped");
  };

  const scanScreen = async () => {
    if (!videoRef.current || !stream) { setError("Start screen sharing first."); return; }
    setBusy("Scanning screen with local OCR…"); setError("");
    try {
      const text = await extractScreenText(captureFrame(videoRef.current));
      setScreenText((old) => old && text && old.includes(text) ? old : [old, text].filter(Boolean).join("\n\n--- New screen scan ---\n\n").slice(-12000));
      setOcrStatus(text ? `Extracted ${text.length} characters` : "No readable text found");
    } catch (e) { setError(`OCR failed: ${(e as Error).message}`); }
    finally { setBusy(""); }
  };

  const loadAi = async () => {
    setBusy("Loading local language model…"); setError("");
    try {
      await loadLocalLlm((text, progress) => { setBusy(text); setLlmProgress(Math.round(progress * 100)); });
      setLlmReady(true);
    } catch (e) {
      setModelEnabled(false);
      setLlmReady(false);
      setError(`Local LLM could not load: ${(e as Error).message} The local fallback is still available.`);
    } finally { setBusy(""); }
  };

  const nextQuestion = async (latestAnswer?: string) => {
    setBusy("Generating next question locally…"); setError("");
    try {
      const next = await generateQuestion({
        projectName, screenText, transcript, previousQuestions: turns.map((t) => t.question),
        answer: latestAnswer, turnCount: turns.length, useModel: modelEnabled && llmReady,
        onProgress: (text, progress) => { setBusy(text); setLlmProgress(Math.round(progress * 100)); },
        onModelError: (message) => { setModelEnabled(false); setLlmReady(false); setError(message); }
      });
      setQuestion(next);
      setAnswer("");
      speak(next);
    } catch (e) { setError((e as Error).message); }
    finally { setBusy(""); }
  };

  const submitAnswer = async () => {
    if (!answer.trim()) { setError("Enter or transcribe an answer first."); return; }
    const assigned = dims[turns.length % dims.length];
    const turn: Turn = { question, answer: answer.trim(), dimension: assigned, evidence: [screenText.slice(-300), transcript.slice(-300)].filter(Boolean).join("\n") };
    const updated = [...turns, turn];
    setTurns(updated);
    setTranscript((old) => [old, `Q: ${question}\nA: ${answer.trim()}`].filter(Boolean).join("\n\n").slice(-15000));
    const currentAnswer = answer.trim();
    setAnswer("");
    await nextQuestion(currentAnswer);
  };

  const startMic = async () => {
    setError("");
    if (!navigator.mediaDevices?.getUserMedia || !("MediaRecorder" in window)) {
      setError("Microphone recording is unavailable in this browser."); return;
    }
    try {
      const mic = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = mic;
      const options = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? { mimeType: "audio/webm;codecs=opus" } : undefined;
      const recorder = new MediaRecorder(mic, options);
      chunksRef.current = [];
      recorder.ondataavailable = (event) => { if (event.data.size) chunksRef.current.push(event.data); };
      recorder.onstop = async () => {
        setMicRecording(false);
        mic.getTracks().forEach((track) => track.stop());
        micStreamRef.current = null;
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || "audio/webm" });
        setBusy("Transcribing locally — first run downloads the Whisper model…");
        try {
          setSpeechStatus("Loading local Whisper");
          const text = await transcribeBlob(blob, setSpeechStatus);
          if (text) { setTranscript((old) => [old, text].filter(Boolean).join("\n").slice(-15000)); setAnswer((old) => [old, text].filter(Boolean).join(" ")); }
          setSpeechStatus(text ? "Transcription complete" : "No speech detected");
        } catch (e) { setError(`Local speech transcription failed: ${(e as Error).message}`); setSpeechStatus("Failed"); }
        finally { setBusy(""); }
      };
      recorderRef.current = recorder;
      recorder.start();
      setMicRecording(true);
      setSpeechStatus("Recording — click Stop to transcribe");
    } catch (e) { setError(`Microphone permission failed: ${(e as Error).message}`); }
  };

  const stopMic = () => recorderRef.current?.state === "recording" && recorderRef.current.stop();

  const finishInterview = () => {
    const result = buildReport(projectName, turns, screenText, transcript);
    setReport(result);
    window.speechSynthesis?.cancel();
  };

  const reset = () => {
    stopScreen();
    micStreamRef.current?.getTracks().forEach((track) => track.stop());
    setTurns([]); setScreenText(""); setTranscript(""); setAnswer(""); setReport(null);
    setQuestion("Introduce your project: what problem does it solve, and who is it for?");
    setError(""); setOcrStatus("Waiting for screen");
  };

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand"><div className="brand-mark"><BrainCircuit size={22}/></div><div><strong>ProjectViva <span>AI</span></strong><small>LOCAL PROJECT INTERVIEWER</small></div></div>
        <div className="privacy-pill"><ShieldCheck size={15}/> Browser-only processing <WifiOff size={15}/></div>
      </header>

      <section className="hero">
        <div>
          <div className="eyebrow"><Activity size={14}/> HACKATHON MVP · NO API KEYS</div>
          <h1>Show your work.<br/><span>Explain your thinking.</span></h1>
          <p>Present your project while a local AI interviewer explores your implementation, asks follow-ups, and builds an evidence-based review.</p>
        </div>
        <div className="hero-stat"><span className="pulse-dot"/><div><b>{stream ? "Screen connected" : "Session ready"}</b><small>{stream ? "Capture permission granted" : "Waiting for presentation"}</small></div></div>
      </section>

      <section className="project-bar">
        <label>PROJECT NAME<input value={projectName} onChange={(e) => setProjectName(e.target.value)} placeholder="e.g. AI Disease Prediction"/></label>
        <div className="project-actions">
          <button className="button secondary" onClick={shareScreen}><Monitor size={16}/> Share screen</button>
          <button className="button secondary" onClick={scanScreen} disabled={!stream || !!busy}><ScanText size={16}/> Scan with OCR</button>
          {stream && <button className="icon-button" title="Stop screen sharing" onClick={stopScreen}><Square size={16}/></button>}
        </div>
      </section>

      <section className="main-grid">
        <div className="left-column">
          <article className="panel screen-panel">
            <div className="panel-heading"><div><span className="step-tag">01</span><h2>Presentation feed</h2></div><span className={`status ${stream ? "live" : ""}`}>{stream ? "LIVE" : "NOT SHARING"}</span></div>
            <div className="screen-frame">
              {stream ? <video ref={videoRef} autoPlay muted playsInline /> : <div className="empty-screen"><Monitor size={38}/><b>Your shared screen appears here</b><span>Share a slide, IDE, browser tab, or project UI.</span><button className="button primary" onClick={shareScreen}><Play size={15}/> Start presenting</button></div>}
            </div>
            <div className="panel-foot"><span><ScanText size={14}/>{ocrStatus}</span><button className="text-button" onClick={scanScreen} disabled={!stream || !!busy}>Capture frame →</button></div>
          </article>

          <article className="panel">
            <div className="panel-heading"><div><span className="step-tag">02</span><h2>Screen understanding</h2></div><span className="muted">LOCAL OCR</span></div>
            <textarea className="evidence-box" value={screenText} onChange={(e) => setScreenText(e.target.value)} placeholder="OCR results will appear here. You can also paste notes or extracted code to improve the demo."/>
            <div className="hint">OCR runs in the browser. Review the extracted text for mistakes before the interview.</div>
          </article>

          <article className="panel">
            <div className="panel-heading"><div><span className="step-tag">03</span><h2>Speech transcript</h2></div><span className="muted">LOCAL WHISPER</span></div>
            <div className="transcript-box">{transcript || <span className="placeholder">Transcribed speech and submitted answers will appear here.</span>}</div>
            <div className="inline-actions">
              <button className={`button ${micRecording ? "danger" : "secondary"}`} onClick={micRecording ? stopMic : startMic} disabled={!!busy && !micRecording}>
                {micRecording ? <Square size={15}/> : <Mic size={15}/>} {micRecording ? "Stop & transcribe" : "Record answer"}
              </button>
              <span className="hint">{speechStatus}</span>
            </div>
          </article>
        </div>

        <div className="right-column">
          <article className="panel interviewer-panel">
            <div className="panel-heading"><div><span className="step-tag">04</span><h2>AI interviewer</h2></div><span className="ai-badge"><span className="pulse-dot"/> LOCAL MODEL</span></div>
            <div className="model-card"><div className="model-icon"><BrainCircuit size={20}/></div><div className="model-info"><b>{llmReady ? "Qwen local model ready" : "Local interview engine (fallback ready)"}</b><small>{llmReady ? MODEL_ID : "Use rule-based fallback or load WebGPU model"}</small></div><button className="text-button" onClick={loadAi} disabled={llmReady || !!busy}>{llmReady ? "Ready ✓" : "Load AI"}</button></div>
            {busy && <div className="busy-line"><LoaderCircle size={15} className="spin"/><span>{busy}</span>{llmProgress > 0 && <b>{llmProgress}%</b>}</div>}
            {error && <div className="error-box">{error}</div>}
            <div className="question-card"><div className="question-label"><CircleHelp size={16}/> CURRENT QUESTION</div><h3>{question}</h3><button className="listen-button" onClick={() => speak(question)}><Volume2 size={15}/> Read question aloud</button></div>
            <label className="answer-label">YOUR ANSWER<textarea value={answer} onChange={(e) => setAnswer(e.target.value)} placeholder="Type your answer here, or record it using the microphone…"/></label>
            <div className="answer-actions"><button className="button primary" onClick={submitAnswer} disabled={!!busy || !answer.trim()}><Play size={15}/> Submit & follow up</button><button className="button secondary" onClick={() => void nextQuestion()} disabled={!!busy}><CircleHelp size={15}/> Skip</button></div>
            <div className="session-footer"><span>{turns.length} answer{turns.length === 1 ? "" : "s"} recorded</span><span>{modelEnabled && llmReady ? "LLM enabled" : "Local fallback enabled"}</span></div>
            <div className="model-toggle"><label><input type="checkbox" checked={modelEnabled} onChange={(e) => setModelEnabled(e.target.checked)}/> Use local language model when loaded</label></div>
          </article>

          <article className="panel score-panel">
            <div className="panel-heading"><div><span className="step-tag">05</span><h2>Evaluation rubric</h2></div><FileText size={17} className="muted-icon"/></div>
            {dims.map((dim, index) => <div className="rubric-row" key={dim}><div><span className="rubric-number">0{index + 1}</span><b>{dim}</b></div><span className="rubric-weight">{[30,20,20,30][index]}%</span></div>)}
            <p className="hint">The MVP uses a transparent heuristic baseline. Scores are provisional and should not be treated as a validated academic or hiring assessment.</p>
            <div className="report-actions"><button className="button primary full" onClick={finishInterview}><CheckCircle2 size={16}/> Generate feedback report</button><button className="button secondary full" onClick={reset}><Trash2 size={15}/> Clear session</button></div>
          </article>
        </div>
      </section>

      {report && <section className="panel report-panel">
        <div className="report-header"><div><div className="eyebrow"><CheckCircle2 size={14}/> INTERVIEW COMPLETE</div><h2>{report.projectName} — Feedback report</h2><p className="hint">Generated locally at {new Date(report.createdAt).toLocaleString()}</p></div><button className="button primary" onClick={() => downloadReport(report)}><Download size={16}/> Download JSON</button></div>
        <div className="overall-score"><strong>{report.overall}</strong><span>/ 100<small>Overall provisional score</small></span></div>
        <div className="score-grid">{dims.map((dim) => <div className="score-card" key={dim}><span>{dim}</span><b>{report.scores[dim]}</b><div className="score-track"><i style={{ width: `${report.scores[dim]}%` }}/></div></div>)}</div>
        <div className="feedback-grid"><div><h3>Strengths / session evidence</h3><ul>{report.strengths.map((s) => <li key={s}>{s}</li>)}</ul></div><div><h3>Improvement plan</h3><ul>{report.improvements.map((s) => <li key={s}>{s}</li>)}</ul></div></div>
        <h3>Interview answers</h3>{report.turns.map((t, i) => <div className="turn-card" key={`${i}-${t.question}`}><b>Q{i + 1}: {t.question}</b><p>{t.answer}</p><small>{t.dimension}</small></div>)}
      </section>}

      <footer><span>ProjectViva AI · Local-first prototype</span><span><ShieldCheck size={14}/> No application backend · Session stays in this browser</span></footer>
    </main>
  );
}