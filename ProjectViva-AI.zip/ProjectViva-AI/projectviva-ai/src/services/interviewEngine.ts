import { CreateMLCEngine, type MLCEngine } from "@mlc-ai/web-llm";

let enginePromise: Promise<MLCEngine> | null = null;
let llmDisabledReason: string | null = null;
// The 0.5B quantized model needs substantially less GPU memory than the previous 1.5B model.
export const MODEL_ID = "Qwen2.5-0.5B-Instruct-q4f16_1-MLC";

export function getLlmDisabledReason() { return llmDisabledReason; }

export async function loadLocalLlm(onProgress?: (text: string, progress: number) => void) {
  if (llmDisabledReason) throw new Error(llmDisabledReason);
  if (!("gpu" in navigator)) {
    throw new Error("WebGPU is unavailable in this browser. Enable graphics acceleration in Edge and restart the browser, or use the local fallback.");
  }
  if (!enginePromise) {
    enginePromise = CreateMLCEngine(MODEL_ID, {
      initProgressCallback: (report) => onProgress?.(report.text, report.progress),
      logLevel: "WARN"
    }).catch((error) => {
      enginePromise = null;
      throw error;
    });
  }
  return enginePromise;
}

function fallbackQuestion(screenText: string, transcript: string, turnCount: number) {
  const text = `${screenText}\n${transcript}`.toLowerCase();
  const questions = [
    "Give me a concise overview of the problem your project solves and who benefits from it.",
    "Walk me through the architecture and explain how data moves through the main components.",
    "Which implementation decision was the hardest, and what alternatives did you consider?",
    "How do you test the main functionality and handle failures or invalid input?",
    "Show or describe one important code path and explain why it is implemented this way.",
    "What security, privacy, or performance risks did you consider, and how did you mitigate them?",
    "What would you improve next if you had another week to work on this project?"
  ];
  if (text.includes("api") || text.includes("backend")) {
    return "How does your API/backend handle validation, errors, and communication with the frontend?";
  }
  if (text.includes("database") || text.includes("sql") || text.includes("mongo")) {
    return "Explain your data model and how you prevent invalid or inconsistent data from being stored.";
  }
  if (text.includes("model") || text.includes("machine learning") || text.includes("accuracy")) {
    return "How did you evaluate your model, choose metrics, and check whether it generalizes to new data?";
  }
  return questions[Math.min(turnCount, questions.length - 1)];
}

export async function generateQuestion(input: {
  projectName: string; screenText: string; transcript: string; previousQuestions: string[];
  answer?: string; turnCount: number; useModel: boolean;
  onProgress?: (text: string, progress: number) => void;
  onModelError?: (message: string) => void;
}) {
  const fallback = fallbackQuestion(input.screenText, input.transcript + " " + (input.answer || ""), input.turnCount);
  if (!input.useModel) return fallback;
  try {
    const engine = await loadLocalLlm(input.onProgress);
    // Keep the prompt deliberately short: long prefill prompts have triggered GPU/device
    // failures on some integrated Windows GPUs. The deterministic fallback remains available.
    const compact = (value: string, limit: number) => value.replace(/\s+/g, " ").trim().slice(-limit);
    const prompt = `Project: ${compact(input.projectName || "Student project", 50)}. Ask exactly one concise, non-duplicate technical follow-up based only on this evidence. Latest answer: ${compact(input.answer || "No answer yet", 180)}. Screen: ${compact(input.screenText, 100)}. Prior: ${compact(input.previousQuestions.slice(-2).join(" | "), 100)}. Return only the question.`;
    const response = await engine.chat.completions.create({
      messages: [
        { role: "system", content: "Technical interviewer. Ask one short question only." },
        { role: "user", content: prompt }
      ],
      temperature: 0.4,
      max_tokens: 96
    });
    return response.choices[0]?.message?.content?.trim().replace(/^["']|["']$/g, "") || fallback;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error("Local LLM failed; using deterministic local fallback.", error);
    // WebGPU device-loss errors often leave the underlying engine disposed. Never reuse it.
    // Disable retries for this page session and keep the interview usable through fallback.
    if (/device was lost|device hung|gpu|disposed|webgpu|out of memory|allocation/i.test(message)) {
      llmDisabledReason = `Local model paused after a GPU/runtime error. The interview will continue with the local fallback. Reload the page to retry the smaller model. Details: ${message}`;
      enginePromise = null;
      input.onModelError?.(llmDisabledReason);
    }
    return fallback;
  }
}

export function speak(text: string) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 0.95;
  window.speechSynthesis.speak(utterance);
}