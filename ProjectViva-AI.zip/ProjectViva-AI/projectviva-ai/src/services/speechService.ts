import { pipeline, env } from "@huggingface/transformers";

type Transcriber = (audio: Float32Array, options?: Record<string, unknown>) => Promise<{ text?: string }>;
let transcriberPromise: Promise<Transcriber> | null = null;

const SPEECH_MODEL = "onnx-community/whisper-tiny.en";

export function loadTranscriber(onProgress?: (message: string) => void): Promise<Transcriber> {
  if (!transcriberPromise) {
    // First use downloads the public model into the browser cache. For a fully offline
    // deployment, bundle the model files locally and configure env.localModelPath.
    env.allowLocalModels = true;
    env.allowRemoteModels = true;
    env.useBrowserCache = true;
    transcriberPromise = (pipeline("automatic-speech-recognition", SPEECH_MODEL, {
      // Keep Whisper on WASM/CPU so it does not compete with WebLLM for WebGPU resources.
      device: "wasm",
      dtype: "q8",
      progress_callback: (event: any) => {
        const status = event?.status || "Loading speech model…";
        const progress = typeof event?.progress === "number" ? ` ${Math.round(event.progress)}%` : "";
        onProgress?.(`${status}${progress}`);
      }
    }) as unknown as Promise<Transcriber>).catch((error) => {
      // Do not permanently cache a rejected promise; the user can retry after fixing connectivity.
      transcriberPromise = null;
      const message = error instanceof Error ? error.message : String(error);
      if (/unexpected token\s*['"]?</i.test(message) || /doctype|not valid json/i.test(message)) {
        throw new Error(`Whisper model files could not be read as JSON. A model download returned HTML instead. Check internet access, VPN/proxy filtering, and the failed Hugging Face request, then retry. Original error: ${message}`);
      }
      throw new Error(`Could not load the local Whisper model (${SPEECH_MODEL}). Check internet access for the first download, then retry. ${message}`);
    });
  }
  return transcriberPromise;
}

/** Decode microphone audio to mono 16 kHz PCM and run Whisper locally in the browser. */
export async function transcribeBlob(blob: Blob, onProgress?: (message: string) => void): Promise<string> {
  if (!blob.size) throw new Error("No audio was recorded. Record a short answer and try again.");
  const AudioContextCtor = window.AudioContext || (window as any).webkitAudioContext;
  if (!AudioContextCtor) throw new Error("This browser does not support audio decoding. Update Edge or type your answer instead.");

  const context: AudioContext = new AudioContextCtor();
  try {
    const model = await loadTranscriber(onProgress);
    const decoded = await context.decodeAudioData((await blob.arrayBuffer()).slice(0));
    const mono = new Float32Array(decoded.length);
    for (let ch = 0; ch < decoded.numberOfChannels; ch++) {
      const channel = decoded.getChannelData(ch);
      for (let i = 0; i < channel.length; i++) mono[i] += channel[i] / decoded.numberOfChannels;
    }

    const targetRate = 16000;
    const outputLength = Math.floor(mono.length * targetRate / decoded.sampleRate);
    if (outputLength < 1) throw new Error("The recording was too short or could not be decoded. Please record again.");
    const resampled = new Float32Array(outputLength);
    const ratio = decoded.sampleRate / targetRate;
    for (let i = 0; i < outputLength; i++) resampled[i] = mono[Math.min(Math.floor(i * ratio), mono.length - 1)] ?? 0;

    const result = await model(resampled, { chunk_length_s: 20, stride_length_s: 3 });
    return (result.text || "").trim();
  } finally {
    if (context.state !== "closed") await context.close().catch(() => undefined);
  }
}
