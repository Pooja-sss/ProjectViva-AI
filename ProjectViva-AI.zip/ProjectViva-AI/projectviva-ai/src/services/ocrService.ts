import { createWorker, type Worker } from "tesseract.js";

let workerPromise: Promise<Worker> | null = null;

export async function extractScreenText(image: HTMLCanvasElement | HTMLImageElement) {
  if (!workerPromise) workerPromise = createWorker("eng");
  const worker = await workerPromise;
  const result = await worker.recognize(image);
  return result.data.text.trim();
}

export async function terminateOcr() {
  if (workerPromise) {
    const worker = await workerPromise;
    await worker.terminate();
    workerPromise = null;
  }
}