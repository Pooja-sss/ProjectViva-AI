import type { Report, Scores, Turn, Dimension } from "../types";

const dimensions: Dimension[] = [
  "Technical depth", "Clarity", "Originality", "Implementation understanding"
];

function scoreDimension(turns: Turn[], dimension: Dimension) {
  const related = turns.filter((turn) => turn.dimension === dimension && turn.answer.trim());
  if (!related.length) return 45;
  // A transparent heuristic baseline; not a validated assessment model.
  const meanLength = related.reduce((sum, turn) => sum + turn.answer.trim().split(/\s+/).length, 0) / related.length;
  const detail = Math.min(25, Math.round(meanLength / 4));
  const evidence = related.reduce((sum, turn) => sum + (turn.answer.match(/\b(because|for example|tested|implemented|measured|trade-?off|error|validation|accuracy|latency)\b/gi)?.length || 0), 0);
  return Math.max(35, Math.min(90, 48 + detail + Math.min(17, evidence * 2)));
}

export function buildReport(projectName: string, turns: Turn[], screenText: string, transcript: string): Report {
  const scores = Object.fromEntries(dimensions.map((d) => [d, scoreDimension(turns, d)])) as Scores;
  const overall = Math.round(scores["Technical depth"] * 0.30 + scores["Clarity"] * 0.20 +
    scores["Originality"] * 0.20 + scores["Implementation understanding"] * 0.30);
  const answered = turns.filter((turn) => turn.answer.trim()).length;
  const strengths = [
    answered ? `Completed ${answered} interview response(s).` : "Interview started; answer more questions for a meaningful report.",
    screenText.trim() ? "Presentation text was captured and used as interview context." : "Add screen content to improve evidence coverage.",
    transcript.trim() ? "Speech transcript is available for review." : "No transcript captured yet; use local speech transcription or enter notes manually."
  ];
  const improvements = [
    "Support important technical claims with a concrete implementation example.",
    "Explain trade-offs and why alternatives were not chosen.",
    "Describe testing, failure handling, and how success was measured.",
    "Review the transcript and screen evidence; the heuristic scores are provisional, not a validated hiring or academic assessment."
  ];
  return { projectName: projectName || "Student project", createdAt: new Date().toISOString(), overall, scores, strengths, improvements, turns, screenText, transcript };
}

export function downloadReport(report: Report) {
  const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `projectviva-report-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}