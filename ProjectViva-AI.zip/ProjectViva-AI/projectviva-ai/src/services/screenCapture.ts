export async function startScreenCapture(onStream: (stream: MediaStream) => void) {
  if (!navigator.mediaDevices?.getDisplayMedia) {
    throw new Error("Screen capture is unavailable. Use a recent version of Chrome or Edge.");
  }
  const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
  onStream(stream);
  stream.getVideoTracks()[0]?.addEventListener("ended", () => {
    stream.getTracks().forEach((track) => track.stop());
  });
  return stream;
}

export function captureFrame(video: HTMLVideoElement): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  canvas.width = video.videoWidth || 1280;
  canvas.height = video.videoHeight || 720;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Could not create screenshot canvas.");
  context.drawImage(video, 0, 0, canvas.width, canvas.height);
  return canvas;
}