# ProjectViva AI — 3-minute showcase guide

## Reliable demo path
1. Double-click `RUN_PROJECTVIVA.bat` and wait for the browser to open.
2. Enter a project name such as `Cyber-Sentinel: AI Security Monitoring`.
3. For a controlled demo, paste a short project summary into the **Screen understanding** evidence box. This avoids screen-share permissions or OCR quality becoming a blocker.
4. Keep the optional local language model unloaded for the most reliable path. The app's deterministic interviewer is ready without GPU setup or model downloads.
5. Answer the interview question in the answer field, then click **Submit & follow up**. Repeat for 2–3 turns.
6. Click **Generate feedback report** and show the score breakdown and downloaded JSON report.
7. If time permits, demonstrate **Share screen** and **Scan with OCR**. Browser permission is required. Microphone transcription is optional and downloads a local Whisper model on first use.

## What is local and what may download
- App processing runs in the browser; there is no application backend and no API key.
- The rule-based interviewer and report generation work without loading the LLM.
- OCR and Whisper model assets, and the optional WebLLM model, download from public hosting on first use and require internet at that point.
- WebLLM requires compatible WebGPU hardware and may be unstable on some integrated GPUs. Do not load it during a time-critical demo unless you have tested it on the presentation machine.
- Evaluation scores are heuristic/demo feedback, not a validated hiring assessment.

## Requirements
- Windows 10/11
- Node.js 20 or newer
- Current Microsoft Edge or Chrome
- Internet for first-time npm installation and optional model downloads

## If the browser does not open
Open PowerShell in this folder and run:
```powershell
npm.cmd install
npm.cmd run dev
```
Then open the localhost URL printed in the terminal.
